# IPL-2022
 Case study on IPL 2022
